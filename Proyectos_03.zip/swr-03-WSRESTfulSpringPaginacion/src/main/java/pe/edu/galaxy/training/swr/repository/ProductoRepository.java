package pe.edu.galaxy.training.swr.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.galaxy.training.swr.domain.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {
	
	List<Producto> findByNombreLikeIgnoreCase(String nombre);
	
	Page<Producto> findByNombreLikeIgnoreCase(String nombre, Pageable pageable);

}
