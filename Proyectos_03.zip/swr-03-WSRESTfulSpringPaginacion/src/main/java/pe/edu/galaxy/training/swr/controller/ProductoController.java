package pe.edu.galaxy.training.swr.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import pe.edu.galaxy.training.swr.bean.BusquedaParam;
import pe.edu.galaxy.training.swr.bean.ResponseBean;
import pe.edu.galaxy.training.swr.domain.Producto;
import pe.edu.galaxy.training.swr.service.ServiceFactory;
import pe.edu.galaxy.training.swr.util.WebApplicationException;

@EnableSpringDataWebSupport
@RestController
@RequestMapping(path="/v1/productos", produces=MediaType.APPLICATION_JSON_VALUE, consumes= MediaType.APPLICATION_JSON_VALUE)
public class ProductoController {
	
	@Autowired
	private ServiceFactory serviceFactory;
	
	//@Autowired
	//private HttpServletRequest request;

	@GetMapping
	public ResponseEntity<Object> get(@Valid BusquedaParam busquedaParam, @PageableDefault(page = 0, size = 3) /*UriComponentsBuilder ucBuilder,*/ Pageable pageable) {
		System.out.println("get");
		
		System.out.println("nombre: " + busquedaParam.getNombre());
		
		if(busquedaParam.getNombre() == null) {
			busquedaParam.setNombre("");
		}
		
		ResponseBean<Producto> responseBean = new ResponseBean<>();
		
		Page<Producto> listaTmp = serviceFactory.getProductoService().buscarPorNombre("%" + busquedaParam.getNombre() + "%", pageable);
		
		if(listaTmp.hasContent()) {
			for (Producto producto : listaTmp.getContent()) {
				producto.add(linkTo(methodOn(ProductoController.class).getById(producto.getIdProduct())).withSelfRel());
			}
			
			if(listaTmp.hasNext()) {
				UriComponentsBuilder nextLinkBuilder = linkTo((methodOn(ProductoController.class).get(null, /*null,*/ null))).toUriComponentsBuilder();
				//UriComponentsBuilder nextLinkBuilder = ServletUriComponentsBuilder.fromServletMapping(request).path(request.getRequestURI());
				//UriComponentsBuilder nextLinkBuilder = ucBuilder;
				if(!busquedaParam.getNombre().isEmpty()) {
					nextLinkBuilder.queryParam("nombre", busquedaParam.getNombre());					
				}
				nextLinkBuilder.queryParam("page", listaTmp.nextPageable().getPageNumber());
			    nextLinkBuilder.queryParam("size", pageable.getPageSize());
			    pageable.getSort().forEach(p -> nextLinkBuilder.queryParam("sort", p.getProperty() + (p.getDirection().isDescending()?",DESC":"")));
			    responseBean.add(new Link(nextLinkBuilder.build().toUriString()).withRel("next"));
			}
			
			if(listaTmp.hasPrevious()) {
				UriComponentsBuilder prevLinkBuilder = linkTo((methodOn(ProductoController.class).get(null, /*null,*/ null))).toUriComponentsBuilder();
				//UriComponentsBuilder prevLinkBuilder = ServletUriComponentsBuilder.fromServletMapping(request).path(request.getRequestURI());
				//UriComponentsBuilder prevLinkBuilder = ucBuilder;
				if(!busquedaParam.getNombre().isEmpty()) {
					prevLinkBuilder.queryParam("nombre", busquedaParam.getNombre());					
				}
				prevLinkBuilder.queryParam("page", listaTmp.previousPageable().getPageNumber());
				prevLinkBuilder.queryParam("size", pageable.getPageSize());
			    pageable.getSort().forEach(p -> prevLinkBuilder.queryParam("sort", p.getProperty() + (p.getDirection().isDescending()?",DESC":"")));
			    responseBean.add(new Link(prevLinkBuilder.build().toUriString()).withRel("prev"));
			}
			
			responseBean.setContent(listaTmp.getContent());
		}

		return new ResponseEntity<Object>(responseBean, HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public Producto getById(@PathVariable("id") int id) {
		System.out.println("getById");
		Producto producto = serviceFactory.getProductoService().buscarPorId(id);
		
		producto.add(linkTo(methodOn(ProductoController.class).getById(producto.getIdProduct())).withSelfRel().withType("GET"));
		producto.add(linkTo(methodOn(ProductoController.class).insert(producto)).withSelfRel().withType("POST"));
		producto.add(linkTo(methodOn(ProductoController.class).update(producto)).withSelfRel().withType("PUT"));
		producto.add(linkTo(methodOn(ProductoController.class).delete(producto.getIdProduct())).withSelfRel().withType("DELETE"));
		
		return producto;
	}

	@PostMapping
	public ResponseEntity<Object> insert(@RequestBody @Valid Producto producto){
		System.out.println("insert");
		
		System.out.println(producto);
		
		serviceFactory.getProductoService().registrar(producto);
		
		ResponseBean<Producto> responseBean = new ResponseBean<>("Se registró correctamente", true);
		responseBean.add(linkTo(methodOn(ProductoController.class).getById(producto.getIdProduct())).withSelfRel());
		
		return new ResponseEntity<Object>(responseBean, HttpStatus.OK);
	}

	@PutMapping
	public ResponseEntity<Object> update(@RequestBody @Valid Producto producto) {
		System.out.println("update");
		
		System.out.println(producto);
		
		if(producto.getId() == null) {
			throw new WebApplicationException(serviceFactory.getUtilProperties().getMessage("vali.idRequerido.message"), HttpStatus.BAD_REQUEST);
		}
		
		serviceFactory.getProductoService().registrar(producto);
		
		return new ResponseEntity<Object>(new ResponseBean<>("Se actualizó correctamente", true), HttpStatus.OK);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Object> delete(@PathVariable("id") int id) {
		System.out.println("delete");
		
		System.out.println("id " + id);
		
		Producto producto = serviceFactory.getProductoService().buscarPorId(id);
		
		if(producto == null) {
			throw new WebApplicationException(serviceFactory.getUtilProperties().getMessage("vali.prodNoEncontrado.message"), HttpStatus.BAD_REQUEST);
		}
		
		serviceFactory.getProductoService().eliminar(producto);
		
		return new ResponseEntity<Object>(new ResponseBean<>("Se eliminó correctamente", true), HttpStatus.OK);
	}

}
