package pe.edu.galaxy.training.swr.util;

public class WebApplicationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public WebApplicationException() {
	}
	
	public WebApplicationException(String message) {
		super(message);
	}

}
