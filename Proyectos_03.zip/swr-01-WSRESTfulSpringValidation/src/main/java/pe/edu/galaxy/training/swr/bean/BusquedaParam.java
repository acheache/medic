package pe.edu.galaxy.training.swr.bean;

import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class BusquedaParam {
	
	@Size(min=3, message="Mínimo 3 caracteres")
	private String nombre;

}
