package pe.edu.galaxy.training.swr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Getter;
import pe.edu.galaxy.training.swr.util.UtilProperties;

@Service
public class ServiceFactory {
	
	@Autowired
	@Getter
	private ProductoService productoService;
	
	@Autowired
	@Getter
	private UtilProperties utilProperties;

}