package pe.edu.galaxy.training.swr.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;

import pe.edu.galaxy.training.swr.bean.ResponseBean;

@ControllerAdvice
public class UtilExceptionController {
	
	@InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.initDirectFieldAccess();
    }

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> handleAllException(Exception exception) {
		
		if(exception instanceof MethodArgumentNotValidException) {
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
			headers.add("exception", exception.getMessage());
			return new ResponseEntity<Object>(new ResponseBean(prepareMessage((MethodArgumentNotValidException)exception), false), headers, HttpStatus.BAD_REQUEST);
		}
		else if(exception instanceof BindException) {
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
			headers.add("exception", exception.getMessage());
			return new ResponseEntity<Object>(new ResponseBean(prepareMessage((BindException)exception), false), headers, HttpStatus.BAD_REQUEST);
		}else if(exception instanceof WebApplicationException) {
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
			headers.add("exception", exception.getMessage());
			return new ResponseEntity<Object>(new ResponseBean(exception.getMessage(), false), headers, HttpStatus.BAD_REQUEST);
		}else {
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
			headers.add("exception", exception.getMessage());
			return new ResponseEntity<Object>(new ResponseBean(exception.getMessage(), false), headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	private List<String> prepareMessage(MethodArgumentNotValidException  exception) {
		
		List<String> result = new ArrayList<>(); 
		for( FieldError fieldError: exception.getBindingResult().getFieldErrors() ){
			result.add(fieldError.getField() + ": " + fieldError.getDefaultMessage());
		}

		return result;
	}
	
	private List<String> prepareMessage(BindException  exception) {
		
		List<String> result = new ArrayList<>(); 
		for( FieldError fieldError: exception.getBindingResult().getFieldErrors() ){
			result.add(fieldError.getField() + ": " + fieldError.getDefaultMessage());
		}

		return result;
	}

}
