package pe.edu.galaxy.training.swr.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.galaxy.training.swr.domain.Producto;
import pe.edu.galaxy.training.swr.repository.ProductoRepository;

@Service
public class ProductoService {
	
	@Autowired
	private ProductoRepository productRepository;

	public void registrar(Producto producto){
		productRepository.save(producto);
	}
	
	public void eliminar(Producto producto){
		productRepository.delete(producto);
	}
	
	public Producto buscarPorId(Integer id){
		Optional<Producto> result = productRepository.findById(id);
		if(result.isPresent()) {
			return result.get();
		}else {
			return null;
		}
	}
	
	public List<Producto> buscarTodo(){
		return productRepository.findAll();
	}
	
	public List<Producto> buscarPorNombre(String nombre){
		return productRepository.findByNombreLikeIgnoreCase(nombre);
	}

}
