package pe.edu.galaxy.training.swr.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pe.edu.galaxy.training.swr.bean.BusquedaParam;
import pe.edu.galaxy.training.swr.bean.ResponseBean;
import pe.edu.galaxy.training.swr.domain.Producto;
import pe.edu.galaxy.training.swr.service.ServiceFactory;
import pe.edu.galaxy.training.swr.util.WebApplicationException;

@RestController
@RequestMapping(path="v1/productos", produces=MediaType.APPLICATION_JSON_VALUE, consumes= MediaType.APPLICATION_JSON_VALUE)
public class ProductoController {
	
	@Autowired
	private ServiceFactory serviceFactory;

	//@RequestMapping
	@GetMapping
	public List<Producto> get(@Valid BusquedaParam busquedaParam) {
		System.out.println("get");
		
		System.out.println("nombre: " + busquedaParam.getNombre());
		
		if(busquedaParam.getNombre() == null) {
			busquedaParam.setNombre("");
		}
		
		List<Producto> listaTmp = serviceFactory.getProductoService().buscarPorNombre("%" + busquedaParam.getNombre() + "%");

		return listaTmp;
	}
	
	//@RequestMapping("/{id}")
	@GetMapping("/{id}")
	public Producto getById(@PathVariable("id") int id) {
		System.out.println("getById");
		return serviceFactory.getProductoService().buscarPorId(id);
	}
	
	//@RequestMapping(method=RequestMethod.POST)
	@PostMapping
	public ResponseEntity<Object> insert(@RequestBody @Valid Producto producto){
		System.out.println("insert");
		
		System.out.println(producto);
		
		serviceFactory.getProductoService().registrar(producto);
		
		return new ResponseEntity<Object>(new ResponseBean("Se registró correctamente", true), HttpStatus.OK);
	}
	
	//@RequestMapping(method=RequestMethod.PUT)
	@PutMapping
	public ResponseEntity<Object> update(@RequestBody @Valid Producto producto) {
		System.out.println("update");
		
		System.out.println(producto);
		
		if(producto.getId() == null) {
			throw new WebApplicationException(serviceFactory.getUtilProperties().getMessage("vali.idRequerido.message"));
		}
		
		serviceFactory.getProductoService().registrar(producto);
		
		return new ResponseEntity<Object>(new ResponseBean("Se actualizó correctamente", true), HttpStatus.OK);
	}
	
	//@RequestMapping(path="/{id}", method=RequestMethod.DELETE)
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> delete(@PathVariable("id") int id) {
		System.out.println("delete");
		
		System.out.println("id " + id);
		
		Producto producto = serviceFactory.getProductoService().buscarPorId(id);
		
		if(producto == null) {
			throw new WebApplicationException(serviceFactory.getUtilProperties().getMessage("vali.prodNoEncontrado.message"));
		}
		
		serviceFactory.getProductoService().eliminar(producto);
		
		return new ResponseEntity<Object>(new ResponseBean("Se eliminó correctamente", true), HttpStatus.OK);
	}

}
