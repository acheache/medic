package pe.edu.galaxy.training.swr.util;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import pe.edu.galaxy.training.swr.bean.ResponseBean;

@Component
public class RestAuthenticationEntryPoint implements AuthenticationEntryPoint {

	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authenticationException) throws IOException, ServletException {

		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.addHeader("exception", authenticationException.getMessage());
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
		
		ObjectMapper mapper = new ObjectMapper();
		String result = mapper.writeValueAsString(new ResponseBean<>(authenticationException.getMessage(), false));
		
		response.getOutputStream().println(result);
		
	}
}