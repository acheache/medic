package pe.edu.galaxy.training.swr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.galaxy.training.swr.domain.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
	
	Usuario findByUsuario(String usuario);
	
	Usuario findByUsuarioAndClave(String usuario, String clave);

}
