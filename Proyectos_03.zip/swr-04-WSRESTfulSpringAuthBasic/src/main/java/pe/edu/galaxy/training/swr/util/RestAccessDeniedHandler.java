package pe.edu.galaxy.training.swr.util;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import pe.edu.galaxy.training.swr.bean.ResponseBean;

@Component
public class RestAccessDeniedHandler implements AccessDeniedHandler {

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException exc)
			throws IOException, ServletException {

		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.addHeader("exception", exc.getMessage());
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
		
		ObjectMapper mapper = new ObjectMapper();
		String result = mapper.writeValueAsString(new ResponseBean<>(exc.getMessage(), false));
		
		response.getOutputStream().println(result);
		
	}
}