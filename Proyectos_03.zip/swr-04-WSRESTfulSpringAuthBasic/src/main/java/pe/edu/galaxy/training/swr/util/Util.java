package pe.edu.galaxy.training.swr.util;

import java.security.MessageDigest;
import java.util.Base64;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Util {
	
    public static String digestPassword(String plainTextPassword) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(plainTextPassword.getBytes("UTF-8"));
            byte[] passwordDigest = md.digest();
            return new String(Base64.getEncoder().encode(passwordDigest));
        } catch (Exception e) {
            throw new RuntimeException("Exception encoding password", e);
        }
    }
    
    public static String digestPasswordBCryp(String plainTextPassword) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		return passwordEncoder.encode(plainTextPassword);
    }
    
    public static void main(String[] args) {
		System.out.println(digestPassword("admin"));
		System.out.println(digestPasswordBCryp("admin"));
	}

}