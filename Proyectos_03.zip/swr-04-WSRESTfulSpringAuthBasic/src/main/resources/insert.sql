INSERT INTO usuario (id, usuario, clave) values (1, 'admin', '$2a$10$SnR8R/jiEWmtkjlZ6/mLEeoG4UKD2UI.Ak5r/.rqilg1.zZsnuBGm');

INSERT INTO producto (id, nombre, descripcion) values (1, 'Galleta', 'Galleta Oreo');
INSERT INTO producto (id, nombre, descripcion) values (2, 'Detergente', 'Detergente Ace');
INSERT INTO producto (id, nombre, descripcion) values (3, 'Crema Dental', 'Crema dental Colgate');
INSERT INTO producto (id, nombre, descripcion) values (4, 'Lejia', 'Descripcion');
INSERT INTO producto (id, nombre, descripcion) values (5, 'Gaseosa', 'Descripcion');