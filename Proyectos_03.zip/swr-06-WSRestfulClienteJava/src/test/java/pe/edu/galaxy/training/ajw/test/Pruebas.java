package pe.edu.galaxy.training.ajw.test;

import com.google.gson.Gson;

import pe.edu.galaxy.training.swr.bean.Producto;
import pe.edu.galaxy.training.swr.bean.ResponseBean;
import pe.edu.galaxy.training.swr.util.UtilREST;

public class Pruebas {
	
	public static void main(String[] args) {
		
		listar();
		
	}
	
	public static void listar() {
		try {
			
			String url = "http://localhost:8081/swrWSRESTfulSpring1Validation/api/v1/productos";
			
			String result = UtilREST.getREST(url);
			
			if(result.contains("false")) {
				Gson gson = new Gson();
				ResponseBean responseBean = gson.fromJson(result, ResponseBean.class);
				System.out.println(responseBean);
			}else {
				Gson gson = new Gson();
				Producto[] productos = gson.fromJson(result, Producto[].class);
				
				for (Producto producto : productos) {
					System.out.println(producto);
				}	
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
