INSERT INTO usuario (id, usuario, clave) values (1, 'admin', 'jGl25bVBBBW96Qi9Te4V37Fnqchz/Eu4qB9vKrRIqRg=');

INSERT INTO producto (id, nombre, descripcion) values (1, 'Galleta', 'Galleta Oreo');
INSERT INTO producto (id, nombre, descripcion) values (2, 'Detergente', 'Detergente Ace');
INSERT INTO producto (id, nombre, descripcion) values (3, 'Crema Dental', 'Crema dental Colgate');
INSERT INTO producto (id, nombre, descripcion) values (4, 'Lejia', 'Descripcion');
INSERT INTO producto (id, nombre, descripcion) values (5, 'Gaseosa', 'Descripcion');