package pe.edu.galaxy.training.swr.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import pe.edu.galaxy.training.swr.bean.ResponseBean;

public class JWTAuthorizationFilter extends GenericFilterBean {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		
		// Get the HTTP Authorization header from the request
		String authorizationHeader = req.getHeader(HttpHeaders.AUTHORIZATION);
		
		if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer")) {
			
			String mensaje = "Authorization Header not found";
			
			res.setContentType(MediaType.APPLICATION_JSON_VALUE);
			res.addHeader("exception", mensaje);
			res.setStatus(HttpStatus.BAD_REQUEST.value());
			
			ObjectMapper mapper = new ObjectMapper();
			String result = mapper.writeValueAsString(new ResponseBean<>(mensaje, false));
			
			response.getOutputStream().println(result);
	        return;
		}

		// Extract the token from the HTTP Authorization header
        String token = authorizationHeader.substring("Bearer".length()).trim();

        try {
        	
        	//Sin Rol
        	Jwts.parser().setSigningKey(Util.generateKey()).parseClaimsJws(token);
        	SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken("", null, new ArrayList<>()));

        	//Con Rol
//        	Claims claims = Jwts.parser().setSigningKey(Util.generateKey()).parseClaimsJws(token).getBody();
//        	String user = claims.getSubject();
//        	
//        	Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
//        	if(claims.get("ROLES", String.class) != null) {
//	        	String[] roles = claims.get("ROLES", String.class).split(",");
//	        	for (String role : roles) {
//	        		authorities.add(new SimpleGrantedAuthority(role));
//				}
//        	}
//        	
//        	JwtUser userTmp = new JwtUser(user, authorities);
//        	
//        	SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(userTmp, null, authorities));
        	
        }catch (Exception e) {
            
            String mensaje = e.getMessage();
			
			res.setContentType(MediaType.APPLICATION_JSON_VALUE);
			res.addHeader("exception", mensaje);
			res.setStatus(HttpStatus.UNAUTHORIZED.value());
			
			ObjectMapper mapper = new ObjectMapper();
			String result = mapper.writeValueAsString(new ResponseBean<>(mensaje, false));
			
			response.getOutputStream().println(result);
            
	        return;
        }

		chain.doFilter(req, res);

	}

}