package pe.edu.galaxy.training.swr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.galaxy.training.swr.domain.Usuario;
import pe.edu.galaxy.training.swr.repository.UsuarioRepository;

@Service
public class UsuarioService {
	
	@Autowired
	private UsuarioRepository usuarioRepository;

	public Usuario buscarParaLogin(Usuario usuario){
		return usuarioRepository.findByUsuarioAndClave(usuario.getUsuario(), usuario.getClave());
	}

}