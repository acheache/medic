package pe.edu.galaxy.training.swr.util;

import java.security.Key;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Base64;
import java.util.Date;
import java.util.Map;

import javax.crypto.spec.SecretKeySpec;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class Util {
	
    public static String digestPassword(String plainTextPassword) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(plainTextPassword.getBytes("UTF-8"));
            byte[] passwordDigest = md.digest();
            return new String(Base64.getEncoder().encode(passwordDigest));
        } catch (Exception e) {
            throw new RuntimeException("Exception encoding password", e);
        }
    }
    
    public static String digestPasswordBCryp(String plainTextPassword) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		return passwordEncoder.encode(plainTextPassword);
    }
    
    public static Key generateKey() {
        String keyString = "simplekey";
        Key key = new SecretKeySpec(keyString.getBytes(), 0, keyString.getBytes().length, "DES");
        return key;
    }
    
    public static String getToken(String sub, String iss, Map<String, Object> claims) {
		long tiempo = System.currentTimeMillis();
        String jwtToken = Jwts.builder()
                .setSubject(sub)
                .setIssuer(iss)
                //.addClaims(claims)
                .setClaims(claims)
                .setIssuedAt(new Date(tiempo))
                //.setExpiration(new Date(tiempo+900000))
                .setExpiration(toDate(LocalDateTime.now().plusMinutes(1L)))
                .signWith(SignatureAlgorithm.HS256, Util.generateKey())
                .compact();
        return jwtToken;
    }
    
    public static void main(String[] args) {
		System.out.println(digestPassword("admin"));
		System.out.println(digestPasswordBCryp("admin"));
	}
    
    public static Date toDate(LocalDateTime localDateTime) {
    	return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }
}