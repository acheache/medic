package pe.edu.galaxy.training.swr.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pe.edu.galaxy.training.swr.bean.ResponseBean;
import pe.edu.galaxy.training.swr.domain.Producto;
import pe.edu.galaxy.training.swr.domain.Usuario;
import pe.edu.galaxy.training.swr.service.ServiceFactory;
import pe.edu.galaxy.training.swr.util.Util;
import pe.edu.galaxy.training.swr.util.WebApplicationException;

@RestController
@RequestMapping(path="/v1/login", produces=MediaType.APPLICATION_JSON_VALUE, consumes= MediaType.APPLICATION_JSON_VALUE)
public class AuthResource {
	
	@Autowired
	private ServiceFactory serviceFactory;
	
	@Autowired
	private HttpServletRequest request;
	
	@PostMapping
	public ResponseEntity<Object> insert(@RequestBody @Valid Usuario usuario){
		System.out.println("insert");
		
		System.out.println(usuario);
		
		usuario.setClave(Util.digestPassword(usuario.getClave()));
		
		Usuario usuarioTmp = serviceFactory.getUsuarioService().buscarParaLogin(usuario);
		
		if(usuarioTmp == null) {
			throw new WebApplicationException("Usuario y/o clave incorrecto", HttpStatus.BAD_REQUEST);
		}
		
		Map<String, Object> roles = new HashMap<>();
		roles.put("ROLES", "ROLE_USER");
		
		String token = Util.getToken(usuario.getUsuario(), request.getContextPath(), roles);
		
		ResponseBean<Producto> responseBean = new ResponseBean<>("Ingreso correcto", true);

		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + token);
		return new ResponseEntity<Object>(responseBean, headers, HttpStatus.OK);
	}
	

}
