package pe.edu.galaxy.training.swr.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.hateoas.ResourceSupport;

@XmlRootElement(name = "response")
public class ResponseBean extends ResourceSupport {
	
    private String message;

    private boolean success;
    
    private List<String> validations;
    
    public ResponseBean() {
	}

    public ResponseBean(String message, boolean success) {
		super();
		this.message = message;
		this.success = success;
	}
    
    public ResponseBean(List<String> validations, boolean success) {
		super();
		this.validations = validations;
		this.success = success;
	}

	@XmlElement
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@XmlElement
	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}
	
	public void setValidations(List<String> validations) {
		this.validations = validations;
	}
	
	public List<String> getValidations() {
		return validations;
	}
	

}
