package pe.edu.galaxy.training.swr.bean;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Saludo extends ResourceSupport {

    private final String contenido;

    @JsonCreator
    public Saludo(@JsonProperty("contenido") String contenido) {
        this.contenido = contenido;
    }

    public String getContent() {
        return contenido;
    }
}