package pe.edu.galaxy.training.swr.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import pe.edu.galaxy.training.swr.bean.Saludo;

@RestController
public class SaludoResource {

    private static final String TEMPLATE = "Hola, %s!";

    @RequestMapping("/saludo")
    public HttpEntity<Saludo> saludar(
            @RequestParam(value = "nombre", required = false, defaultValue = "Mundo") String nombre) {

        Saludo saludo = new Saludo(String.format(TEMPLATE, nombre));
        saludo.add(linkTo(methodOn(SaludoResource.class).saludar(nombre)).withSelfRel());

        return new ResponseEntity<>(saludo, HttpStatus.OK);
    }
}