package pe.edu.galaxy.training.swr.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pe.edu.galaxy.training.swr.bean.BusquedaParam;
import pe.edu.galaxy.training.swr.bean.ResponseBean;
import pe.edu.galaxy.training.swr.domain.Producto;
import pe.edu.galaxy.training.swr.service.ServiceFactory;
import pe.edu.galaxy.training.swr.util.WebApplicationException;

@RestController
@RequestMapping(path="/v1/productos", produces=MediaType.APPLICATION_JSON_VALUE, consumes= MediaType.APPLICATION_JSON_VALUE)
public class ProductoController {
	
	@Autowired
	private ServiceFactory serviceFactory;

	@GetMapping
	public List<Producto> get(@Valid BusquedaParam busquedaParam) {
		System.out.println("get");
		
		System.out.println("nombre: " + busquedaParam.getNombre());
		
		if(busquedaParam.getNombre() == null) {
			busquedaParam.setNombre("");
		}
		
		List<Producto> listaTmp = serviceFactory.getProductoService().buscarPorNombre("%" + busquedaParam.getNombre() + "%");
		
		for (Producto producto : listaTmp) {
			producto.add(linkTo(methodOn(ProductoController.class).getById(producto.getIdProduct())).withSelfRel());
		}

		return listaTmp;
	}
	
	@GetMapping("/{id}")
	public Producto getById(@PathVariable("id") int id) {
		System.out.println("getById");
		Producto producto = serviceFactory.getProductoService().buscarPorId(id);
		
		producto.add(linkTo(methodOn(ProductoController.class).getById(producto.getIdProduct())).withSelfRel().withType("GET"));
		producto.add(linkTo(methodOn(ProductoController.class).insert(producto)).withSelfRel().withType("POST"));
		producto.add(linkTo(methodOn(ProductoController.class).update(producto)).withSelfRel().withType("PUT"));
		producto.add(linkTo(methodOn(ProductoController.class).delete(producto.getIdProduct())).withSelfRel().withType("DELETE"));
		
		return producto;
	}

	@PostMapping
	public ResponseEntity<Object> insert(@RequestBody @Valid Producto producto){
		System.out.println("insert");
		
		System.out.println(producto);
		
		serviceFactory.getProductoService().registrar(producto);
		
		ResponseBean responseBean = new ResponseBean("Se registró correctamente", true);
		responseBean.add(linkTo(methodOn(ProductoController.class).getById(producto.getIdProduct())).withSelfRel());
		
		return new ResponseEntity<Object>(responseBean, HttpStatus.OK);
	}

	@PutMapping
	public ResponseEntity<Object> update(@RequestBody @Valid Producto producto) {
		System.out.println("update");
		
		System.out.println(producto);
		
		if(producto.getId() == null) {
			throw new WebApplicationException(serviceFactory.getUtilProperties().getMessage("vali.idRequerido.message"), HttpStatus.BAD_REQUEST);
		}
		
		serviceFactory.getProductoService().registrar(producto);
		
		return new ResponseEntity<Object>(new ResponseBean("Se actualizó correctamente", true), HttpStatus.OK);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Object> delete(@PathVariable("id") int id) {
		System.out.println("delete");
		
		System.out.println("id " + id);
		
		Producto producto = serviceFactory.getProductoService().buscarPorId(id);
		
		if(producto == null) {
			throw new WebApplicationException(serviceFactory.getUtilProperties().getMessage("vali.prodNoEncontrado.message"), HttpStatus.BAD_REQUEST);
		}
		
		serviceFactory.getProductoService().eliminar(producto);
		
		return new ResponseEntity<Object>(new ResponseBean("Se eliminó correctamente", true), HttpStatus.OK);
	}

}
