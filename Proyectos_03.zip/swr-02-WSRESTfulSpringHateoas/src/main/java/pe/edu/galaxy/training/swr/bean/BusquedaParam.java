package pe.edu.galaxy.training.swr.bean;

import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class BusquedaParam {
	
	public BusquedaParam() {
	}
	
	public BusquedaParam(String nombre) {
		super();
		this.nombre = nombre;
	}

	@Size(min=3, message="Mínimo 3 caracteres")
	private String nombre;

}
