package com.mitocode.service;

import com.mitocode.model.Especialidad;

public interface IEspecialidadService extends ICRUD<Especialidad>{

}
